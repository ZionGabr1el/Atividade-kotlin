package com.example.myfirstapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class SomaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_soma)
    }

    fun somar(view: View) {
        //ENTRADA
        val editTextNumero1 = findViewById<EditText>(R.id.etNumero1)
        val editTextNumero2 = findViewById<EditText>(R.id.etNumero2)

        val n1 = editTextNumero1.text.toString().toDouble()
        val n2 = editTextNumero2.text.toString().toDouble()

        //PROCESSAMENTO
        val soma = n1 + n2

        //SAIDA
       findViewById<TextView>(R.id.tvResult).apply {
            //text = message
            text = String.format("%.4f", soma)
        }

        findViewById<TextView>(R.id.tvMessage).apply {
            //text = message
            text = "Sua soma é"
    }
}
}