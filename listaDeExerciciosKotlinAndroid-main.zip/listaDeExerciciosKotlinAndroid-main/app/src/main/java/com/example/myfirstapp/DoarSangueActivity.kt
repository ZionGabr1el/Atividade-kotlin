package com.example.myfirstapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class DoarSangueActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_doar_sangue)
    }

    fun resultado2(view: View) {
        //ENTRADA
        val editTextIdade2 = findViewById<EditText>(R.id.etIda)


        val idade2 = editTextIdade2.text.toString().toDouble()


        //PROCESSAMENTO
        val dado2 = if (idade2 < 16 && idade2 > 65) "Não pode doar"
        else if (idade2 >= 18 && idade2 <= 65) "Pode doar"
        else "Não pode doar"


        //SAIDA
        findViewById<TextView>(R.id.tvResult).apply {
            //text = message
            text = String.format("%.3f", idade2)

        }
        findViewById<TextView>(R.id.tvMessage).apply {
            //text = message
            text = "Você " + dado2
        }
    }
}