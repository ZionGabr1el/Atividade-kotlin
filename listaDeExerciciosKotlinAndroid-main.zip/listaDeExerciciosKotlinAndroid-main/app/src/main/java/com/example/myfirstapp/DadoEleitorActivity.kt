package com.example.myfirstapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class DadoEleitorActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dado_eleitor)
    }

    fun resultado(view: View) {
        //ENTRADA
        val editTextIdade = findViewById<EditText>(R.id.etIdade)


        val idade = editTextIdade.text.toString().toDouble()


        //PROCESSAMENTO
        val dado = if (idade < 16 && idade > 65) "Eleitor facultativo"
        else if (idade >= 18 && idade <= 65) "Eleitor obrigatório"
        else "Eleitor facultativo"



        //SAIDA
        findViewById<TextView>(R.id.tvResult).apply {
            //text = message
            text = String.format("%.3f", idade)

        }
        findViewById<TextView>(R.id.tvMessage).apply {
            //text = message
            text = "Sua posição de eleitor é " + dado
        }
    }
}